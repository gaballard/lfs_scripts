/* TestA.java */

package com.xyz;

import junit.framework.*;

public class TestA extends TestCase {

    private Front1 f1 = null;

    public void setUp () {
        f1 = new Front1();
    }
    public void testFrontZero () {
        assertEquals (0, f1.runTest(0));
    }
    public void testFrontPos () {
        assertEquals (1, f1.runTest(1));
        assertEquals (16, f1.runTest(2));
    }
    public void testFrontPos2 () {
        assertEquals (12, f1.runTest(3));
        assertEquals (12, f1.runTest(4));
        assertEquals (79, f1.runTest(5));
    }
    public void testFrontPos3 () {
        assertEquals (80, f1.runTest(6));
        assertEquals (81, f1.runTest(7));
    }
    public void testFrontNeg () {
        assertEquals (-4, f1.runTest(-1));
        assertEquals (-8, f1.runTest(-2));
    }
    public void testFrontNeg2 () {
        assertEquals (-12, f1.runTest(-3));
        assertEquals (-16, f1.runTest(-4));
    }
}
