/* TestC.java */

package com.xyz;

import junit.framework.*;

public class TestC extends TestCase {

    private Front3 f3 = null;

    public void testZero () {
        f3 = new Front3 ();
        assertEquals (0, f3.runTest(0));
    }
    public void testPos () {
        f3 = new Front3 ();
        assertEquals ( 520, f3.runTest(1));
        assertEquals (1040, f3.runTest(2));
    }
    public void testNeg () {
        f3 = new Front3 ();
        assertEquals ( 14, f3.runTest(-1));
        assertEquals ( 15, f3.runTest(-2));
    }
}
