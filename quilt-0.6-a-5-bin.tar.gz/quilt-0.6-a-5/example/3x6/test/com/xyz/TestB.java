/* TestB.java */

package com.xyz;

import junit.framework.*;

public class TestB extends TestCase {

    private Front1 f1 = null;
    private Front2 f2 = null;

    public TestB () {}

    public void setUp() {
        f1 = new Front1();
        f2 = new Front2();
    }

    public void testZero() {
        assertEquals (   0, f1.runTest(0) );
        assertEquals (   9, f2.runTest(0) );
    }
    public void testPos1() {
        assertEquals (   1, f1.runTest(1) );
        assertEquals (3481, f2.runTest(2) );
    }
    public void testPos2() {
        assertEquals (  54, f1.runTest(3) );
        assertEquals (  11, f2.runTest(4) );
    }
    public void testPos3() {
        assertEquals (  79, f1.runTest(5) );
        assertEquals (   6, f2.runTest(6) );
    }
    public void testNeg1() {
        assertEquals (  -4, f1.runTest(-1) );
        assertEquals (   8, f2.runTest(-2) );
    }
    public void testNeg2() {
        assertEquals ( -12, f1.runTest(-3) );
        assertEquals (  32, f2.runTest(-4) );
    }
}
