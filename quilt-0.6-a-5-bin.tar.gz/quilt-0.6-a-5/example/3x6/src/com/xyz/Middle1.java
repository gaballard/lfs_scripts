package com.xyz;

public class Middle1 {
    private int a;
    private int b;

    public Middle1 (int a, int b) {
        this.a = a;
        this.b = b;
    }

    public int aMid1 (int x) {
        return x + a + b;
    }
    public int bMid1 (int x) {
        Back back = Back.getInstance();     // singleton
        
        switch (x) {
            case 0:                         // unreachable from TestA
                back.addGoodness (42);      // then fall through
            case 1:
                return a * a;
            case 2:
                return b * b;
            case 3:
                a = x + back.getGoodness();
                break;
            case 4:
                b = x;
                break;
            default:
                a = b = 37;
        }
        return x + a + b;
    }
}
