package com.xyz;

public class Middle2 {
    private int a;
    private int b;
    private int c;
    
    public Middle2 (int a, int b, int c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public int aMid2 (int x) {      // probe from TestB via Front2
        a += x;
        b -= x;
        c *= x;
        return x;
    }
    public int bMid2 (int x) {      // TestC via Front3
        if (x==59) {
            Back back = Back.getInstance();
            back.addGoodness(x);
            return back.getGoodness();
        } else if (x >= 0) {
            return x * a * b * c;
        } else {
            return x * x * a * b;
        }
    }
}
