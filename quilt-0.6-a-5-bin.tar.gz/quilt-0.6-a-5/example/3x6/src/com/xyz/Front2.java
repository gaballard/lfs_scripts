package com.xyz;

public class Front2 {

    public Front2 () {
    }

    private int a3 (int x) {
        return x % 7;
    }
    public int runTest(int x) {
        if ( 0 <= x && x <=5 ) {
            Middle1 m1 = new Middle1(3, 59);
            return m1.bMid1(x);
        } else if (x < 0) {
            Middle2 m2 = new Middle2 (-1, -2, -3);
            return m2.bMid2(x);
        } else {
            return a3(x);
        }
    }
}
