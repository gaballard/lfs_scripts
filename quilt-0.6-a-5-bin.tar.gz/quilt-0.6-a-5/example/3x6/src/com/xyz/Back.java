/* Back.java */

package com.xyz;

public class Back {

    private static final Back INSTANCE = new Back();
    private int goodness;
    
    private Back () {
        goodness = 0;
    }
    public static Back getInstance() {
        return INSTANCE;
    }
    public void addGoodness (int g) {
        goodness += g;
    }
    public int getGoodness () {
        return goodness;
    }
    public void noGoodness () {
        goodness = 0;
    }
}
