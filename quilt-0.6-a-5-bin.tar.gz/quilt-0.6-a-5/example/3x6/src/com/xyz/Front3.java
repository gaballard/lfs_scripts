package com.xyz;

public class Front3 {

    public Front3 () {
    }

    public int a3 (int x) {
        return 13 - x;
    }
    public int runTest(int x) {
        Middle2 m2 = new Middle2(5,8,13);   // fib
        if (x >= 0) 
            return m2.bMid2(x);
        else 
            return a3(x);
    }

}
