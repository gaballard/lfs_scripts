package com.xyz;

public class Front1 {
    private int x;
    
    public Front1 () {
    }

    private boolean isPos() {
        return x > 0;
    }
    public int runTest(int x) {
        this.x = x;
        Middle1 m1 = new Middle1(x, 2*x);
        if (isPos())
            return m1.bMid1(x);         // involves back-end goodness
        else
            return m1.aMid1(x);
    }
}
