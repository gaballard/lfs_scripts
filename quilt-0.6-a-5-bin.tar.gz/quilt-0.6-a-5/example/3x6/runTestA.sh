/usr/local/j2sdk/bin/java \
-cp .:\
/usr/local/j2sdk/lib/tools.jar:\
/usr/local/ant/lib/ant.jar:\
/usr/local/ant/lib/junit.jar:\
../../target/classes:\
target/classes:target/test-classes org.quilt.textui.TestRunner \
com.xyz.TestA \
checkCoverage="true" \
checkIncludes="com.xyz"   \
checkExcludes="com.xyz.Test" \
filtertrace="true" \
formatter="org.quilt.reports.PlainFormatter" \
haltOnError="true" haltOnFailure="true" \
propfile="myPropFile" \ 
showOutput="true" 
